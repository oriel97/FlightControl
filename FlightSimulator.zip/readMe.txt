Flight-Simulator-Desktop-App Desktop application for controling
 server - the flight simulator gear.

First run the progeam and enter ip and port ,then press connect,the flight gear simulator need to be open, 
the program will connect as a client, the control over plane will be at the user hands.
As the plane will start to move,the user will see in the dashborad the value of the important sliders.
the user can use the wheel (that contanianig the joystick and the sliders) and direct the plane on the map.

Oriel Asraf
Tomer Sultanian